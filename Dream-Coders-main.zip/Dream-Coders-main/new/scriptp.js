// scriptp.js (updated)
document.addEventListener('DOMContentLoaded', function() {
    // Handle referrer registration form submission
    const referrerForm = document.getElementById('referrer-form');
    if (referrerForm) {
        referrerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Simulate form data collection (in a real app, you'd send this to a backend)
            const formData = {
                fullName: this.querySelector('input[name="fullName"]').value,
                email: this.querySelector('input[name="email"]').value,
                companyName: this.querySelector('input[name="companyName"]').value,
                password: this.querySelector('input[name="password"]').value
            };

            // Store data in localStorage (for demo purposes) or send to a backend
            localStorage.setItem('referrerData', JSON.stringify(formData));

            // Redirect to post referral page (updated to match the actual file name)
            window.location.href = 'postref.html';
        });
    }

    // Handle referral posting form submission
    const referralForm = document.getElementById('referral-form');
    if (referralForm) {
        referralForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Collect referral data
            const formData = {
                companyName: this.querySelector('input[name="companyName"]').value,
                jobRole: this.querySelector('input[name="jobRole"]').value,
                description: this.querySelector('textarea[name="description"]').value,
                prerequisites: this.querySelector('textarea[name="prerequisites"]').value,
                salary: this.querySelector('input[name="salary"]').value
            };

            // Simulate posting (in a real app, send to backend and store)
            console.log('Referral Posted:', formData);

            // Show success message or redirect
            alert('Referral posted successfully!');
            window.location.href = 'index.html'; // Redirect back to home page or dashboard
        });
    }
});